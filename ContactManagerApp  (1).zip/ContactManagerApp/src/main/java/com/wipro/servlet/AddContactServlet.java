package com.wipro.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.model.Contact;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addContact")
public class AddContactServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    List<Contact> contactList = new ArrayList<>();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");

        String phone = request.getParameter("phone");

        String email = request.getParameter("email");

        Contact contact = new Contact(name, phone, email);

        contactList.add(contact);

        request.setAttribute("contacts", contactList);

        request.getRequestDispatcher("contacts.jsp")
               .forward(request, response);
    }
}