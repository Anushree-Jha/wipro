package com.wipro.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.model.Contact;

@WebServlet("/updateContact")
public class UpdateContactServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        int index = Integer.parseInt(
                request.getParameter("index"));

        String name = request.getParameter("name");

        String phone = request.getParameter("phone");

        String email = request.getParameter("email");

        Contact updatedContact =
                new Contact(name, phone, email);

        AddContactServlet.contactList
                         .set(index, updatedContact);

        request.setAttribute("contacts",
                AddContactServlet.contactList);

        request.setAttribute("message",
                "Contact Updated Successfully!");

        request.getRequestDispatcher("contacts.jsp")
               .forward(request, response);
    }
}