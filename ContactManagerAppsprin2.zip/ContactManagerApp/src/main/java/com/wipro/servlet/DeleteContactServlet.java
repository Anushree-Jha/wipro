package com.wipro.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteContact")
public class DeleteContactServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        int index = Integer.parseInt(
                request.getParameter("index"));

        AddContactServlet.contactList.remove(index);

        request.setAttribute("contacts",
                AddContactServlet.contactList);

        request.setAttribute("message",
                "Contact Deleted Successfully!");

        request.getRequestDispatcher("contacts.jsp")
               .forward(request, response);
    }
}