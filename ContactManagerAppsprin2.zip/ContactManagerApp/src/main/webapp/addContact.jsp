<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Contact</title>

<style>

body{
    font-family:Arial;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

form{
    width:300px;
    display:flex;
    flex-direction:column;
    gap:10px;
}

input{
    padding:10px;
}

button{
    padding:10px;
    background-color:green;
    color:white;
    border:none;
    border-radius:5px;
}

</style>

</head>
<body>

<form action="addContact" method="post">

<h2>Add Contact</h2>

<input type="text" name="name" placeholder="Enter Name" required>

<input type="text" name="phone" placeholder="Enter Phone" required>

<input type="email" name="email" placeholder="Enter Email" required>

<button type="submit">
Save Contact
</button>

</form>

</body>
</html>