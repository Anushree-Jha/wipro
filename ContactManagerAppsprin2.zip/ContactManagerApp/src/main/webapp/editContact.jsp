<%@ page import="com.wipro.servlet.AddContactServlet" %>
<%@ page import="com.wipro.model.Contact" %>

<%
int index = Integer.parseInt(request.getParameter("index"));

Contact c = AddContactServlet.contactList.get(index);
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit Contact</title>
</head>
<body>

<h2>Edit Contact</h2>

<form action="updateContact" method="post">

<input type="hidden"
       name="index"
       value="<%= index %>">

Name:
<input type="text"
       name="name"
       value="<%= c.getName() %>">

<br><br>

Phone:
<input type="text"
       name="phone"
       value="<%= c.getPhone() %>">

<br><br>

Email:
<input type="email"
       name="email"
       value="<%= c.getEmail() %>">

<br><br>

<button type="submit">
Update Contact
</button>

</form>

</body>
</html>