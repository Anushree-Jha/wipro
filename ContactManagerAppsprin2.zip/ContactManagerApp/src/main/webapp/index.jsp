<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Contact Manager</title>

<style>

body{
    font-family: Arial;
    text-align:center;
    margin-top:100px;
}

a{
    text-decoration:none;
    background-color:blue;
    color:white;
    padding:10px 20px;
    border-radius:5px;
}

</style>

</head>
<body>

<h1>Welcome to Contact Manager</h1>

<br><br>

<a href="addContact.jsp">Add Contact</a>

</body>
</html>