<%@ page import="java.util.*,com.wipro.model.Contact" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Contacts</title>
</head>
<body>

<h2>Saved Contacts</h2>
<h3 style="color:green;">
<%= request.getAttribute("message") %>
</h3>

<table border="1">

<tr>
<th>Name</th>
<th>Phone</th>
<th>Email</th>
<th>Actions</th>
</tr>

<%
List<Contact> contacts = (List<Contact>) request.getAttribute("contacts");

if(contacts != null){

    for(Contact c : contacts){
%>

<tr>

<td><%= c.getName() %></td>

<td><%= c.getPhone() %></td>

<td><%= c.getEmail() %></td>

<td>

<a href="editContact.jsp?index=<%= contacts.indexOf(c) %>">
Edit
</a>

|

<a href="deleteContact?index=<%= contacts.indexOf(c) %>">
Delete
</a>

</td>

</tr>

<%
    }
}
%>

</table>

</body>
</html>