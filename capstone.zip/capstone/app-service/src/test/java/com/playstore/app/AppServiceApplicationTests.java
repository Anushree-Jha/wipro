package com.playstore.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
