package com.playstore.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.playstore.app.entity.App;
import com.playstore.app.service.AppService;

@RestController
@RequestMapping("/apps")
public class AppController {

    @Autowired
    private AppService service;

    @PostMapping
    public App addApp(@RequestBody App app) {
        return service.addApp(app);
    }
    
    

    @GetMapping
    public List<App> getAllApps() {
        return service.getAllApps();
    }

    @GetMapping("/{id}")
    public App getAppById(@PathVariable Long id) {
        return service.getAppById(id);
    }

    @PutMapping("/{id}")
    public App updateApp(@PathVariable Long id,
                         @RequestBody App app) {
        return service.updateApp(id, app);
    }

    @DeleteMapping("/{id}")
    public String deleteApp(@PathVariable Long id) {
        service.deleteApp(id);
        return "App Deleted Successfully";
    }

    @GetMapping("/search")
    public List<App> searchByName(@RequestParam String name) {
        return service.searchByName(name);
    }

    @GetMapping("/genre/{genre}")
    public List<App> getAppsByGenre(@PathVariable String genre) {
        return service.getAppsByGenre(genre);
    }

    @GetMapping("/rating/{rating}")
    public List<App> getAppsByRating(@PathVariable Double rating) {
        return service.getAppsByRating(rating);
    }
    
    @GetMapping("/search/{appName}")
    public App getAppByName(@PathVariable String appName) {
        return service.getAppByName(appName);
    }
    
    @GetMapping("/visible")
    public List<App> getVisibleApps() {
        return service.getVisibleApps();
    }
    
    @PostMapping("/download/{appId}")
    public App downloadApp(
            @PathVariable Long appId) {

        return service.downloadApp(appId);
    }
}