package com.playstore.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.playstore.app.entity.App;
import com.playstore.app.repository.AppRepository;

import org.springframework.web.client.RestTemplate;
import com.playstore.app.dto.NotificationDTO;

import com.playstore.app.exception.AppNotFoundException;

@Service
public class AppServiceImpl implements AppService {

    @Autowired
    private AppRepository repository;
    
    @Autowired
    private RestTemplate restTemplate;

    @Override
    public App addApp(App app) {
        return repository.save(app);
    }

    @Override
    public List<App> getAllApps() {
        return repository.findAll();
    }

    @Override
    public App getAppById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new AppNotFoundException(
                                "App not found with id " + id));
    }

    @Override
    public App updateApp(Long id, App app) {

        App existingApp = repository.findById(id).orElse(null);

        if (existingApp != null) {

            existingApp.setAppName(app.getAppName());
            existingApp.setDescription(app.getDescription());
            existingApp.setReleaseDate(app.getReleaseDate());
            existingApp.setVersion(app.getVersion());
            existingApp.setRating(app.getRating());
            existingApp.setGenre(app.getGenre());
            existingApp.setVisible(app.getVisible());
            existingApp.setOwnerId(app.getOwnerId());

            App updatedApp = repository.save(existingApp);

            NotificationDTO notification =
                    new NotificationDTO(
                            updatedApp.getAppName() + " has been updated",
                            "user@gmail.com");

            System.out.println("SENDING NOTIFICATION...");

            restTemplate.postForObject(
                    "http://localhost:8086/notifications",
                    notification,
                    Object.class);

            System.out.println("NOTIFICATION SENT");

            return updatedApp;
            
        }

        return null;
    }

    @Override
    public void deleteApp(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<App> searchByName(String appName) {
        return repository.findByAppNameContainingIgnoreCase(appName);
    }

    @Override
    public List<App> getAppsByGenre(String genre) {
        return repository.findByGenreIgnoreCase(genre);
    }

    @Override
    public List<App> getAppsByRating(Double rating) {
        return repository.findByRatingGreaterThanEqual(rating);
    }
    
    @Override
    public App getAppByName(String appName) {
        return repository.findByAppName(appName)
                .orElse(null);
    }
    
    @Override
    public List<App> getVisibleApps() {
        return repository.findByVisibleTrue();
    }
    
    @Override
    public App downloadApp(Long appId) {

        App app = repository.findById(appId)
                .orElseThrow(() ->
                        new AppNotFoundException(
                                "App not found"));

        app.setDownloadCount(
                app.getDownloadCount() + 1);

        App updatedApp = repository.save(app);

        NotificationDTO notification =
                new NotificationDTO(
                        "Your app "
                        + updatedApp.getAppName()
                        + " was downloaded",
                        "owner@gmail.com"
                );

        restTemplate.postForObject(
                "http://localhost:8086/notifications",
                notification,
                Object.class);

        return updatedApp;
    }
}