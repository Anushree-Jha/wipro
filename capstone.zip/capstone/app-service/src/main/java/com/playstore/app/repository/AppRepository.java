package com.playstore.app.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.playstore.app.entity.App;

public interface AppRepository extends JpaRepository<App, Long> {

    List<App> findByAppNameContainingIgnoreCase(String appName);

    List<App> findByGenreIgnoreCase(String genre);

    List<App> findByRatingGreaterThanEqual(Double rating);
    Optional<App> findByAppName(String appName);
    
    List<App> findByVisibleTrue();
}
