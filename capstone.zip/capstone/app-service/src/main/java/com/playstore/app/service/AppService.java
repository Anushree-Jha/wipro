package com.playstore.app.service;

import java.util.List;

import com.playstore.app.entity.App;

public interface AppService {

    App addApp(App app);

    List<App> getAllApps();

    App getAppById(Long id);

    App updateApp(Long id, App app);

    void deleteApp(Long id);

    List<App> searchByName(String appName);

    List<App> getAppsByGenre(String genre);

    List<App> getAppsByRating(Double rating);
    
    App getAppByName(String appName);
    
    List<App> getVisibleApps();
    
    App downloadApp(Long appId);
}