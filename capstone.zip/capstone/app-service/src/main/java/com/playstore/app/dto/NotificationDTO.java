package com.playstore.app.dto;

public class NotificationDTO {

    private String message;
    private String recipientEmail;

    public NotificationDTO() {
    }

    public NotificationDTO(String message, String recipientEmail) {
        this.message = message;
        this.recipientEmail = recipientEmail;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }
}