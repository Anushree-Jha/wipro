package com.playstore.notification.service;

import java.util.List;

import com.playstore.notification.entity.Notification;

public interface NotificationService {

    Notification sendNotification(Notification notification);

    List<Notification> getAllNotifications();
}