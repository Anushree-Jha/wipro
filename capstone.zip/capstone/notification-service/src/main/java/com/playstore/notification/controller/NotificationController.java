package com.playstore.notification.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.playstore.notification.entity.Notification;
import com.playstore.notification.service.NotificationService;


@RestController
@RequestMapping("/notifications")
@CrossOrigin(origins = "*")
public class NotificationController {

    @Autowired
    private NotificationService service;

    @PostMapping
    public Notification sendNotification(
            @RequestBody Notification notification) {

        return service.sendNotification(notification);
    }

    @GetMapping
    public List<Notification> getAllNotifications() {
        return service.getAllNotifications();
    }
}