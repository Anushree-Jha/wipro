package com.playstore.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.playstore.notification.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

}