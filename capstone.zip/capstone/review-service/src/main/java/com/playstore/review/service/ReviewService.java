package com.playstore.review.service;

import java.util.List;

import com.playstore.review.entity.Review;

public interface ReviewService {

    Review addReview(Review review);

    List<Review> getAllReviews();

    List<Review> getReviewsByApp(Long appId);

}