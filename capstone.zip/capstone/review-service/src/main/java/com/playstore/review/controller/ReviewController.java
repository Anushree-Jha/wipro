package com.playstore.review.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.playstore.review.entity.Review;
import com.playstore.review.service.ReviewService;

@RestController

@RequestMapping("/reviews")

@CrossOrigin(origins = "*")
public class ReviewController {

    @Autowired
    private ReviewService service;

    @PostMapping
    public Review addReview(@RequestBody Review review) {
        return service.addReview(review);
    }

    @GetMapping
    public List<Review> getAllReviews() {
        return service.getAllReviews();
    }

    @GetMapping("/app/{appId}")
    public List<Review> getReviewsByApp(@PathVariable Long appId) {
        return service.getReviewsByApp(appId);
    }
    
    @GetMapping("/owner/app/{appId}")
    public List<Review> getReviewsForOwner(
            @PathVariable Long appId) {

        return service.getReviewsByApp(appId);
    }
}