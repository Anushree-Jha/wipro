package com.playstore.review.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.playstore.review.entity.Review;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByAppId(Long appId);

}