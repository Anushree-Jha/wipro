package com.playstore.review.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.playstore.review.dto.NotificationDto;
import com.playstore.review.entity.Review;
import com.playstore.review.repository.ReviewRepository;

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository repository;

    @Autowired
    private RestClient restClient;

    @Override
    public Review addReview(Review review) {

        Review savedReview = repository.save(review);

        NotificationDto notification =
                new NotificationDto();

        notification.setMessage(
                "New review received for App ID "
                + savedReview.getAppId());

        notification.setRecipientEmail(
                "owner@gmail.com");

        restClient.post()
                .uri("http://localhost:8086/notifications")
                .body(notification)
                .retrieve()
                .body(Object.class);

        System.out.println("REVIEW NOTIFICATION SENT");

        return savedReview;
    }

    @Override
    public List<Review> getAllReviews() {
        return repository.findAll();
    }

    @Override
    public List<Review> getReviewsByApp(Long appId) {
        return repository.findByAppId(appId);
    }
}