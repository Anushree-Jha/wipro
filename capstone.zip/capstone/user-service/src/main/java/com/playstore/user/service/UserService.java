package com.playstore.user.service;

import java.util.List;

import com.playstore.user.entity.User;

import com.playstore.user.dto.LoginResponse;

public interface UserService {

    User register(User user);

    List<User> getAllUsers();

    User getUserById(Long id);

    User updateUser(Long id, User user);

    void deleteUser(Long id);
//    String login(String email, String password);
    LoginResponse login(String email, String password);
}