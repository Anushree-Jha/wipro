package com.playstore.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.playstore.user.entity.User;
import com.playstore.user.repository.UserRepository;

import com.playstore.user.dto.LoginResponse;
import com.playstore.user.security.JwtUtil;

import com.playstore.user.exception.UserNotFoundException;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repository;

    @Override
    public User register(User user) {
        return repository.save(user);
    }

    @Override
    public List<User> getAllUsers() {
        return repository.findAll();
    }

    @Override
    public User getUserById(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new UserNotFoundException(
                                "User not found with id " + id));
    }

    @Override
    public User updateUser(Long id, User user) {

        User existingUser = repository.findById(id).orElse(null);

        if (existingUser != null) {
            existingUser.setUserName(user.getUserName());
            existingUser.setEmail(user.getEmail());
            existingUser.setPassword(user.getPassword());

            return repository.save(existingUser);
        }

        return null;
    }

    @Override
    public void deleteUser(Long id) {
        repository.deleteById(id);
    }
    @Override
    public LoginResponse login(String email, String password) {

        User user = repository.findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException("User not found"));

        if (!user.getPassword().equals(password)) {
            throw new RuntimeException("Invalid Password");
        }

        String token = JwtUtil.generateToken(email);

        return new LoginResponse(token);
    }
}