package com.playstore.owner.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.playstore.owner.entity.Owner;
import java.util.Optional;


public interface OwnerRepository extends JpaRepository<Owner, Long> {
	Optional<Owner> findByEmail(String email);


}
