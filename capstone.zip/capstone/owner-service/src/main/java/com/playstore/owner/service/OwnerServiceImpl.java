package com.playstore.owner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.playstore.owner.entity.Owner;
import com.playstore.owner.repository.OwnerRepository;

import com.playstore.owner.security.JwtUtil;

@Service
public class OwnerServiceImpl implements OwnerService {

    @Autowired
    private OwnerRepository repository;

    @Override
    public Owner register(Owner owner) {
        return repository.save(owner);
    }

    @Override
    public List<Owner> getAllOwners() {
        return repository.findAll();
    }

    @Override
    public Owner getOwnerById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public Owner updateOwner(Long id, Owner owner) {

        Owner existingOwner = repository.findById(id).orElse(null);

        if (existingOwner != null) {

            existingOwner.setOwnerName(owner.getOwnerName());
            existingOwner.setEmail(owner.getEmail());
            existingOwner.setPassword(owner.getPassword());

            return repository.save(existingOwner);
        }

        return null;
    }

    @Override
    public void deleteOwner(Long id) {
        repository.deleteById(id);
    }
    @Override
    public String login(String email, String password) {

        Owner owner = repository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Owner not found"));

        if (!owner.getPassword().equals(password)) {
            throw new RuntimeException("Invalid Password");
        }

        return JwtUtil.generateToken(owner.getEmail());
    }
}