package com.playstore.owner.service;

import java.util.List;

import com.playstore.owner.entity.Owner;

public interface OwnerService {

    Owner register(Owner owner);

    List<Owner> getAllOwners();

    Owner getOwnerById(Long id);

    Owner updateOwner(Long id, Owner owner);

    void deleteOwner(Long id);
    
    String login(String email, String password);
}