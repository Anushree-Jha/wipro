package com.playstore.owner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.playstore.owner.dto.LoginRequest;
import com.playstore.owner.entity.Owner;
import com.playstore.owner.service.OwnerService;

@RestController
@RequestMapping("/owners")
public class OwnerController {

    @Autowired
    private OwnerService service;

    @PostMapping("/register")
    public Owner register(@RequestBody Owner owner) {
        return service.register(owner);
    }

    @GetMapping
    public List<Owner> getAllOwners() {
        return service.getAllOwners();
    }

    @GetMapping("/{id}")
    public Owner getOwnerById(@PathVariable Long id) {
        return service.getOwnerById(id);
    }

    @PutMapping("/{id}")
    public Owner updateOwner(@PathVariable Long id,
                             @RequestBody Owner owner) {
        return service.updateOwner(id, owner);
    }

    @DeleteMapping("/{id}")
    public String deleteOwner(@PathVariable Long id) {
        service.deleteOwner(id);
        return "Owner Deleted Successfully";
    }
    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {

        return service.login(
                request.getEmail(),
                request.getPassword()
        );
    }
}